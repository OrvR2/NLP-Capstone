#!/usr/bin/env python

import sys, zipimport, nltk
# from operator import itemgetter

reload(sys)
sys.setdefaultencoding('utf-8')

for line in sys.stdin:
    #if line.endswith('pos'):
    print line
