SentiWordNet
http://sentiwordnet.isti.cnr.it/

SentiWordNet is a lexical resource for opinion mining. SentiWordNet
assigns to each synset of WordNet three sentiment scores: positivity,
negativity, objectivity.

Stefano Baccianella, Andrea Esuli, and Fabrizio Sebastiani (2010),
SentiWordNet 3.0: An Enhanced Lexical Resource for Sentiment Analysis
and Opinion Mining, Proceedings of the Seventh International
Conference on Language Resources and Evaluation (LREC).
http://nmis.isti.cnr.it/sebastiani/Publications/LREC10.pdf

SentiWordNet is distributed under the Creative Commons Attribution
ShareAlike 3.0 Unported license.
